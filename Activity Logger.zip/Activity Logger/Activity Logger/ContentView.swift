import SwiftUI
import ActivityKit

struct ContentView: View {
    @State private var activityText = ""
    @State private var currentActivityName: String? = nil
    @State private var activityStartDate: Date? = nil
    @State private var elapsedSeconds: Int = 0
    @State private var timerRunning = false

    @State private var currentActivity: Activity<MyActivityAttributes>? = nil

    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        VStack(spacing: 24) {
            Text("Activity Logger")
                .font(.largeTitle.bold())
                .foregroundColor(Color(hex: "#ccbffb"))

            VStack(spacing: 16) {
                TextField("Enter activity", text: $activityText)
                    .padding()
                    .background(.ultraThinMaterial)
                    .foregroundColor(.primary)
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(Color(hex: "#ccbffb").opacity(0.3), lineWidth: 1))
                    .padding(.horizontal)

                Button(action: startActivity) {
                    Text("Save Activity")
                        .fontWeight(.semibold)
                        .padding(.vertical, 14)
                        .padding(.horizontal, 24)
                        .background(.ultraThinMaterial)
                        .foregroundColor(Color(hex: "#ccbffb"))
                        .clipShape(Capsule())
                }
                .disabled(activityText.isEmpty)
            }

            if let name = currentActivityName, let start = activityStartDate {
                VStack(spacing: 8) {
                    Text("⏳ \(name)")
                        .font(.title2)
                        .foregroundColor(Color(hex: "#ccbffb"))

                    Text("Started at: \(formattedDate(start))")
                        .foregroundColor(.secondary)

                    Text("Elapsed: \(formattedElapsed(elapsedSeconds))")
                        .font(.caption.monospacedDigit())
                        .foregroundColor(.primary)

                    Button("Stop Activity") {
                        stopActivity()
                    }
                    .foregroundColor(.red)
                    .padding(.top, 8)
                }
                .padding()
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 20))
            }
        }
        .padding()
        .background(Color.black.ignoresSafeArea())
        .onTapGesture {
            hideKeyboard()
        }
        .onReceive(timer) { _ in
            if timerRunning {
                elapsedSeconds += 1
                Task {
                    await updateLiveActivity()
                }
            }
        }
    }

    func startActivity() {
        guard !activityText.isEmpty else { return }

        currentActivityName = activityText
        activityStartDate = Date()
        elapsedSeconds = 0
        timerRunning = true

        let attributes = MyActivityAttributes(activityName: activityText, startTime: Date())
        let contentState = MyActivityAttributes.ContentState(elapsedSeconds: 0)
        let content = ActivityContent(state: contentState, staleDate: nil)

        do {
            currentActivity = try Activity<MyActivityAttributes>.request(
                attributes: attributes,
                content: content,
                pushType: nil
            )
        } catch {
            print("Failed to start Live Activity: \(error)")
        }

        activityText = ""
    }

    func stopActivity() {
        timerRunning = false
        currentActivityName = nil
        activityStartDate = nil
        elapsedSeconds = 0

        Task {
            await currentActivity?.end(
                ActivityContent(state: MyActivityAttributes.ContentState(elapsedSeconds: elapsedSeconds), staleDate: nil),
                dismissalPolicy: .immediate
            )
            currentActivity = nil
        }
    }

    func updateLiveActivity() async {
        guard let activity = currentActivity else { return }
        let newState = MyActivityAttributes.ContentState(elapsedSeconds: elapsedSeconds)
        await activity.update(ActivityContent(state: newState, staleDate: nil))
    }

    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    func formattedElapsed(_ seconds: Int) -> String {
        let hrs = seconds / 3600
        let mins = (seconds % 3600) / 60
        let secs = seconds % 60
        if hrs > 0 {
            return String(format: "%02d:%02d:%02d", hrs, mins, secs)
        } else {
            return String(format: "%02d:%02d", mins, secs)
        }
    }
}

// Helper to dismiss keyboard
extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

// Hex color initializer
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int = UInt64()
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(.sRGB,
                  red: Double(r) / 255,
                  green: Double(g) / 255,
                  blue: Double(b) / 255,
                  opacity: Double(a) / 255)
    }
}
