import UIKit

struct ImageStorage {
    private static let filename = "background.jpg"

    static func save(image: UIImage) {
        guard let data = image.jpegData(compressionQuality: 0.9) else { return }
        let url = getURL()
        try? data.write(to: url)
    }

    static func load() -> UIImage? {
        let url = getURL()
        guard FileManager.default.fileExists(atPath: url.path),
              let data = try? Data(contentsOf: url),
              let image = UIImage(data: data) else {
            return nil
        }
        return image
    }

    private static func getURL() -> URL {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return dir.appendingPathComponent(filename)
    }
}
