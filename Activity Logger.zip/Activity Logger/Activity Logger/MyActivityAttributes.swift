import ActivityKit
import Foundation

struct MyActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var elapsedSeconds: Int
    }
    
    var activityName: String
    var startTime: Date
}
