//
//  Activity_LoggerTests.swift
//  Activity LoggerTests
//
//  Created by Олександр Потьомкін on 10.06.2025.
//

import Testing
@testable import Activity_Logger

struct Activity_LoggerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
