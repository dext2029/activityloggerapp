import WidgetKit
import SwiftUI
import ActivityKit

struct ActivityWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration<MyActivityAttributes>(for: MyActivityAttributes.self) { context in
            // Lock Screen / Banner UI
            HStack(spacing: 12) {
                Image("AppIcon")
                    .resizable()
                    .frame(width: 24, height: 24)
                    .clipShape(RoundedRectangle(cornerRadius: 6))
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(context.attributes.activityName)
                        .font(.headline.weight(.semibold))
                        .foregroundColor(.primary)

                    Text("Started at \(formattedTime(context.attributes.startTime))")
                        .font(.caption)
                        .foregroundColor(.secondary)

                    Text("Elapsed: \(formattedElapsed(context.state.elapsedSeconds))")
                        .font(.caption2.monospacedDigit())
                        .foregroundColor(.primary)
                }
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.black)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    HStack(spacing: 6) {
                        Image("AppIcon")
                            .resizable()
                            .frame(width: 18, height: 18)
                            .clipShape(RoundedRectangle(cornerRadius: 4))
                        
                        Text(context.attributes.activityName)
                            .font(.headline.weight(.semibold))
                    }
                }

                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 2) {
                        Text("Started at \(formattedTime(context.attributes.startTime)) · Elapsed: \(formattedElapsed(context.state.elapsedSeconds))")
                            .font(.caption2.monospacedDigit())
                    }
                }

            } compactLeading: {
                Image("AppIcon")
                    .resizable()
                    .frame(width: 16, height: 16)
                    .clipShape(RoundedRectangle(cornerRadius: 4))
            } compactTrailing: {
                EmptyView() // Removed second elapsed display
            } minimal: {
                Image("AppIcon")
                    .resizable()
                    .frame(width: 16, height: 16)
                    .clipShape(RoundedRectangle(cornerRadius: 4))
            }
        }
        .configurationDisplayName("Activity Logger Live Activity")
        .description("Shows your current activity and elapsed time")
        .supportedFamilies([.systemMedium, .systemLarge, .accessoryRectangular])
    }

    func formattedTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    func formattedElapsed(_ seconds: Int) -> String {
        let hrs = seconds / 3600
        let mins = (seconds % 3600) / 60
        let secs = seconds % 60
        if hrs > 0 {
            return String(format: "%02d:%02d:%02d", hrs, mins, secs)
        } else {
            return String(format: "%02d:%02d", mins, secs)
        }
    }
}

