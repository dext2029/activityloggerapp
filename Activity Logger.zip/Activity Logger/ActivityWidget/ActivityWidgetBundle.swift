//
//  ActivityWidgetBundle.swift
//  ActivityWidget
//
//  Created by Олександр Потьомкін on 11.06.2025.
//

import WidgetKit
import SwiftUI

@main
struct ActivityWidgetBundle: WidgetBundle {
    var body: some Widget {
        ActivityWidget()
        ActivityWidgetControl()
        ActivityWidgetLiveActivity()
    }
}
